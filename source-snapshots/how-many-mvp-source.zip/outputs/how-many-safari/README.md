# how many? — Safari 변환 패키지

Chrome 버전을 기반으로 iPhone/iPad Safari에 맞춘 웹 확장 소스와 Apple 공식 도구를 호출하는 변환 스크립트입니다. **현재는 설치된 앱이나 완성된 IPA가 아닙니다.** Xcode가 없어 Apple 프로젝트 생성·컴파일·Safari 실기기 실행은 아직 검증하지 못했습니다.

## 지금 필요한 것

Mac App Store에서 **Xcode 전체 앱**을 설치하고 한 번 실행해 초기 설정과 iOS 시뮬레이터 구성요소 설치를 완료하세요. Command Line Tools만으로는 Safari 확장 프로젝트를 만들 수 없습니다.

## 변환

터미널에서 `bash `를 입력한 뒤 이 폴더의 `convert.command` 파일을 끌어다 놓고 Enter를 누릅니다. 또는 이 폴더에서 다음 명령을 실행합니다.

```sh
bash convert.command
```

스크립트는 설치된 Xcode에 따라 최신 `safari-web-extension-packager` 또는 이전 `safari-web-extension-converter`를 선택합니다. 생성 설정 확인 프롬프트가 나오면 이름과 경로를 확인해 진행하세요. `generated` 폴더 안의 `.xcodeproj`가 결과물입니다. 기존 generated 폴더가 있으면 덮어쓰지 않습니다.

프로젝트는 `extension` 폴더를 참조합니다. 변환 후에도 두 폴더를 함께 보관하세요. 코드 수정 시 `extension` 안의 파일을 바꾸고 Xcode에서 다시 빌드합니다. 도구가 지원하지 않는 manifest 키를 경고하면 해당 경고를 검토한 뒤 실행해야 합니다.

## Xcode에서 테스트

1. 생성된 프로젝트에서 **iOS 앱 스킴**을 선택합니다. Mac 타깃도 생성됐다면 iOS 타깃을 사용하세요.
2. 우선 iPhone 시뮬레이터를 선택하고 Run을 누릅니다.
3. 설치된 앱은 확장의 설치/안내를 담당합니다. 타이머는 Safari의 YouTube 페이지에 나타납니다.
4. 시뮬레이터 또는 아이폰의 설정 → 앱 → Safari → 확장 프로그램에서 how many?를 켭니다. OS 버전에 따라 설정 → Safari 아래에 있을 수 있습니다.
5. Safari로 YouTube 웹사이트를 열고 확장의 YouTube 접근을 허용합니다. YouTube 앱으로 이동하면 측정되지 않습니다.
6. 일반 영상과 쇼츠를 각각 10초 이상 재생합니다. 페이지 우측 하단 타이머에서 해당 종류의 시간만 늘어나는지 확인합니다.

실제 iPhone/iPad에 설치할 때는 Mac에 기기를 연결하고, Xcode의 앱 타깃과 확장 타깃 모두에서 Signing & Capabilities의 Team을 본인 계정으로 설정합니다. 번들 식별자 충돌 시 본인 고유 식별자로 바꾸세요. 기기 신뢰 및 개발자 모드는 Xcode/기기의 안내에 따라 설정합니다. 계정의 서명 가능 여부는 Xcode가 확인하며, App Store/TestFlight 배포는 별도 개발자 등록과 배포 절차가 필요합니다. Screen Time/Family Controls entitlement는 이 웹 확장에 필요하지 않습니다.

## Safari용 변경

- `www.youtube.com`, `m.youtube.com`, `youtube.com` 지원
- Safari `browser` API 우선 사용, `chrome` API 대체 지원
- 아이폰/iPad 터치 환경에서는 데스크톱 창 포커스 API에 의존하지 않고 페이지 가시성·활성 탭·영상 재생 진행으로 판단
- 터치 기기에서는 작은 타이머로 시작하며 + 버튼으로 상세 통계 펼치기
- 손가락 드래그, 터치 취소 처리, 화면 회전 시 위치 복귀, 하단 안전 영역 적용
- 확장 백그라운드 연결 중단 후 자동 재시도. 중단 시간을 소급해서 더하지 않음
- iOS 네이티브 전체화면/PiP 감지 시 측정 제외

## 측정과 개인정보

쇼츠는 `/shorts/…`, 일반 영상(라이브 포함)은 `/watch` 주소로 분류합니다. 영상 제목, URL, 검색어, 계정 정보는 저장하지 않습니다. 날짜별 쇼츠/일반 영상 시간과 목표·켜기 설정만 이 확장의 로컬 저장소에 기록합니다. 외부 서버 전송과 기기 간 동기화는 없습니다.

현재 타이머와 색상은 **오늘 쇼츠+일반 영상 합산 시간** 기준입니다. 10분 미만 초록, 10–30분 노랑, 30분 이상 빨강입니다. 목표는 15/30/60분 중 선택합니다.

## 한계 및 검증 상태

- Node 자동 테스트 8개 및 JS/셸 문법 검사로 검증합니다. 이는 실제 Safari의 API 호환성과 화면 동작 검증을 대신하지 않습니다.
- 초기 1초, 영상 전환·반복재생 경계·확장 팝업을 여는 동안 일부 시간은 빠질 수 있습니다.
- 잠금/다른 앱 전환/PiP/전체화면에서 일시정지되는지 실기기 테스트가 필요합니다. 백그라운드 오디오 시간은 지원하지 않습니다.
- YouTube 웹페이지 안에서만 작동합니다. YouTube 앱에는 영향을 주지 않습니다.
- 광고 식별과 Shorts 화면 구조는 YouTube 변경에 따라 보완이 필요합니다. 사람의 실제 시선은 측정하지 않습니다.
- 재생 중/일시정지/탭 전환/잠금/회전/전체화면/쇼츠 넘기기를 iPhone과 iPad에서 각각 검증해야 합니다.

```sh
node --test extension/tests.cjs
```

공식 참고: [Safari 확장 패키징](https://developer.apple.com/documentation/safariservices/packaging-a-web-extension-for-safari), [사이트 접근 권한](https://developer.apple.com/documentation/safariservices/managing-safari-web-extension-permissions).
