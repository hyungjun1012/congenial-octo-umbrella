#!/bin/bash
set -euo pipefail
task_dir="$(cd -- "$(dirname -- "$0")" && pwd)"

# Prefer the full Xcode app without changing the machine's xcode-select setting.
if [ -d /Applications/Xcode.app/Contents/Developer ]; then
  export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
fi
packager=""
for candidate in safari-web-extension-packager safari-web-extension-converter; do
  if /usr/bin/xcrun --find "$candidate" >/dev/null 2>&1; then
    packager="$candidate"
    break
  fi
done
if [ -z "$packager" ]; then
  printf '%s\n' 'Xcode 전체 앱이 필요합니다. App Store에서 Xcode를 설치하고 한 번 실행해 초기 설정을 완료한 후 이 파일을 다시 실행하세요.' >&2
  exit 1
fi
output="$task_dir/generated"
if [ -e "$output" ]; then
  printf '%s\n' 'generated 폴더가 이미 있습니다. 기존 프로젝트를 사용하거나 폴더 이름을 바꾼 뒤 다시 실행하세요. 덮어쓰지 않았습니다.' >&2
  exit 1
fi
help_text="$(/usr/bin/xcrun "$packager" --help 2>&1)"
platform=()
case "$help_text" in
  *--ios-only*) platform=(--ios-only) ;;
  *--ios*) platform=(--ios) ;;
esac
/usr/bin/xcrun "$packager" "$task_dir/extension" \
  --project-location "$output" \
  --app-name HowManySafari \
  --bundle-identifier com.howmany.safari \
  --swift --no-open "${platform[@]}"
printf '%s\n' '변환 완료: generated 폴더의 .xcodeproj를 Xcode로 열어 주세요.'
printf '%s\n' 'iOS 앱/확장 두 타깃의 서명 Team을 설정하고 iPhone 시뮬레이터 또는 연결한 iPhone으로 실행하세요.'
