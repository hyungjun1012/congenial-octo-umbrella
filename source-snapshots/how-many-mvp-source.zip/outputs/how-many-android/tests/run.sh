#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/rule-tests
javac -d build/rule-tests app/src/main/java/com/howmany/app/TimeRules.java tests/TimeRulesTest.java
java -cp build/rule-tests TimeRulesTest
