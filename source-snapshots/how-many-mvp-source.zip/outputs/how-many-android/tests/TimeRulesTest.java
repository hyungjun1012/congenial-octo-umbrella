import com.howmany.app.TimeRules;

public class TimeRulesTest {
  public static void main(String[] args) {
    long[] inputs = {0, 599999, 600000, 1799999, 1800000, 3600000};
    int[] expected = {0, 0, 1, 1, 2, 2};
    for (int i = 0; i < inputs.length; i++)
      if (TimeRules.stage(inputs[i]) != expected[i])
        throw new AssertionError("Boundary " + inputs[i]);
    if (!TimeRules.clock(3661000).equals("01:01:01")) throw new AssertionError("Clock");
    if (!TimeRules.clock(86400000).equals("24:00:00")) throw new AssertionError("24h");
    System.out.println("PASS: 6 color boundary cases and 2 duration formatting cases");
  }
}
