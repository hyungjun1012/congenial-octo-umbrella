package com.howmany.app;

import android.app.*;
import android.content.*;
import android.os.*;

public class ManualService extends Service {
  public IBinder onBind(Intent i) {
    return null;
  }

  public int onStartCommand(Intent i, int flags, int id) {
    if (i != null && "STOP".equals(i.getAction())) {
      stopSelf();
      return START_NOT_STICKY;
    }
    NotificationManager nm = getSystemService(NotificationManager.class);
    nm.createNotificationChannel(
        new NotificationChannel("timer", "수동 타이머", NotificationManager.IMPORTANCE_LOW));
    PendingIntent open =
        PendingIntent.getActivity(
            this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
    PendingIntent stop =
        PendingIntent.getService(
            this,
            1,
            new Intent(this, ManualService.class).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE);
    Notification n =
        new Notification.Builder(this, "timer")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("how many? · 수동 측정 중")
            .setContentText("앱 또는 알림에서 측정을 종료하세요.")
            .setContentIntent(open)
            .addAction(new Notification.Action.Builder(null, "종료", stop).build())
            .setOngoing(true)
            .build();
    startForeground(1, n);
    TimerEngine.get(this).start("수동 타이머", true);
    return START_NOT_STICKY;
  }

  public void onDestroy() {
    TimerEngine t = TimerEngine.get(this);
    if (t.manual) t.stop();
    super.onDestroy();
  }
}
