package com.howmany.app;

import android.content.*;
import android.graphics.Color;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.TextView;
import java.time.*;

final class TimerEngine {
  // This singleton holds only the application context, never an Activity.
  @android.annotation.SuppressLint("StaticFieldLeak")
  static TimerEngine instance;

  static TimerEngine get(Context c) {
    if (instance == null) instance = new TimerEngine(c.getApplicationContext());
    return instance;
  }

  final Context context;
  final android.content.SharedPreferences prefs;
  final Handler handler = new Handler(Looper.getMainLooper());
  String source = "";
  boolean manual = false;
  long session = 0, last = 0;
  TextView bubble;
  final Runnable tick =
      new Runnable() {
        public void run() {
          accrue();
          render();
          handler.postDelayed(this, 1000);
        }
      };

  TimerEngine(Context c) {
    context = c;
    prefs = c.getSharedPreferences("howmany", 0);
  }

  boolean running() {
    return !source.isEmpty();
  }

  void start(String label, boolean isManual) {
    if (running() && source.equals(label) && manual == isManual) return;
    stop();
    source = label;
    manual = isManual;
    session = 0;
    last = SystemClock.elapsedRealtime();
    handler.post(tick);
  }

  void accrue() {
    if (!running()) return;
    long now = SystemClock.elapsedRealtime(), delta = Math.max(0, now - last);
    last = now;
    session += delta;
    long end = System.currentTimeMillis(), cursor = end - delta;
    android.content.SharedPreferences.Editor edit = prefs.edit();
    while (cursor < end) {
      ZonedDateTime z = Instant.ofEpochMilli(cursor).atZone(ZoneId.systemDefault());
      String key = "day_" + z.toLocalDate();
      long boundary =
          z.toLocalDate().plusDays(1).atStartOfDay(z.getZone()).toInstant().toEpochMilli();
      long part = Math.min(end, boundary) - cursor;
      edit.putLong(key, prefs.getLong(key, 0) + part);
      cursor += part;
    }
    edit.apply();
  }

  long today() {
    return prefs.getLong("day_" + LocalDate.now(), 0);
  }

  void stop() {
    accrue();
    source = "";
    manual = false;
    handler.removeCallbacks(tick);
    hide();
  }

  void hide() {
    if (bubble != null) {
      try {
        ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).removeView(bubble);
      } catch (IllegalArgumentException ignored) {
      }
      bubble = null;
    }
  }

  void render() {
    if (!Settings.canDrawOverlays(context)) {
      hide();
      return;
    }
    if (bubble == null) {
      bubble = new TextView(context);
      bubble.setTextSize(14);
      bubble.setPadding(24, 14, 24, 14);
      bubble.setTextColor(Color.rgb(20, 34, 30));
      WindowManager.LayoutParams lp =
          new WindowManager.LayoutParams(
              -2,
              -2,
              WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
              WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                  | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
              android.graphics.PixelFormat.TRANSLUCENT);
      lp.gravity = Gravity.TOP | Gravity.END;
      lp.y = 90;
      lp.x = 12;
      try {
        ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).addView(bubble, lp);
      } catch (RuntimeException e) {
        bubble = null;
        return;
      }
    }
    int[] colors = {0xffc7f0d8, 0xffffe4a3, 0xffffb5ae};
    android.graphics.drawable.GradientDrawable bg =
        new android.graphics.drawable.GradientDrawable();
    bg.setColor(colors[TimeRules.stage(session)]);
    bg.setCornerRadius(30);
    bubble.setBackground(bg);
    bubble.setText("how many?  " + TimeRules.clock(session) + "\n" + TimeRules.nudge(session));
  }
}
