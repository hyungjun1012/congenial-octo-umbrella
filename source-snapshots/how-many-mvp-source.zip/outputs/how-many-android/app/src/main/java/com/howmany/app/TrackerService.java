package com.howmany.app;

import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;

public class TrackerService extends AccessibilityService {
  TimerEngine timer;
  boolean registered;
  final BroadcastReceiver screen =
      new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
          if (!timer.manual) timer.stop();
        }
      };

  protected void onServiceConnected() {
    timer = TimerEngine.get(this);
    IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
    if (Build.VERSION.SDK_INT >= 33) registerReceiver(screen, f, Context.RECEIVER_NOT_EXPORTED);
    else registerReceiver(screen, f);
    registered = true;
  }

  public void onAccessibilityEvent(AccessibilityEvent e) {
    if (timer == null) timer = TimerEngine.get(this);
    if (timer.manual) return;
    if (e.getPackageName() == null) return;
    String p = e.getPackageName().toString();
    boolean unlocked =
        !((android.app.KeyguardManager) getSystemService(KEYGUARD_SERVICE)).isKeyguardLocked();
    if (unlocked
        && timer.prefs.getBoolean("auto", false)
        && timer.prefs.getBoolean("app_" + p, false)) timer.start(p, false);
    else timer.stop();
  }

  public void onInterrupt() {
    if (timer != null && !timer.manual) timer.stop();
  }

  public void onDestroy() {
    if (registered) unregisterReceiver(screen);
    if (timer != null && !timer.manual) timer.stop();
    super.onDestroy();
  }
}
