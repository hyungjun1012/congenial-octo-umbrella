package com.howmany.app;

import java.util.Locale;

public final class TimeRules {
  public static int stage(long ms) {
    return ms < 600000 ? 0 : ms < 1800000 ? 1 : 2;
  }

  public static String clock(long ms) {
    long s = Math.max(0, ms) / 1000;
    return String.format(Locale.ROOT, "%02d:%02d:%02d", s / 3600, s / 60 % 60, s % 60);
  }

  public static String nudge(long ms) {
    long m = ms / 60000;
    return m < 10 ? "지금, 내 시간을 알아차리는 중" : m < 30 ? "잠깐 쉬어갈까요?" : "다음 5분은 나를 위해 써보세요";
  }
}
