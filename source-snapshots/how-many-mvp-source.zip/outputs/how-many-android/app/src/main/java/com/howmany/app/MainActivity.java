package com.howmany.app;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
  final Handler handler = new Handler(Looper.getMainLooper());
  TimerEngine timer;
  TextView total, current, status, insight;
  Button overlay, access;
  LinearLayout page;
  final int ink = 0xff173e34, muted = 0xff657a70;
  final Runnable refresh =
      new Runnable() {
        public void run() {
          update();
          handler.postDelayed(this, 1000);
        }
      };

  public void onCreate(Bundle b) {
    super.onCreate(b);
    timer = TimerEngine.get(this);
    ScrollView scroll = new ScrollView(this);
    scroll.setBackgroundColor(0xfff5f5ee);
    page = new LinearLayout(this);
    page.setOrientation(LinearLayout.VERTICAL);
    page.setPadding(26, 20, 26, 30);
    scroll.addView(page);
    setContentView(scroll);
    scroll.setOnApplyWindowInsetsListener(
        (v, insets) -> {
          v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
          return insets;
        });
    text("HOW MANY?     /     DIGITAL WELLBEING", 12, muted);
    space(22);
    text("스크롤 사이,\n나를 위한 시간.", 32, ink);
    space(10);
    text("작은 알아차림이 하루를 바꿉니다.", 15, muted);
    space(26);
    LinearLayout card = new LinearLayout(this);
    card.setOrientation(LinearLayout.VERTICAL);
    card.setPadding(24, 24, 24, 24);
    GradientDrawable bg = new GradientDrawable();
    bg.setColor(ink);
    bg.setCornerRadius(28);
    card.setBackground(bg);
    page.addView(card);
    card.addView(label("오늘 측정한 앱 이용 시간", 14, 0xffc5ddcb));
    total = label("00:00:00", 40, Color.WHITE);
    total.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
    card.addView(total);
    current = label("지금은 쉬어가는 중", 14, 0xffc5ddcb);
    card.addView(current);
    insight = label("", 14, muted);
    page.addView(insight);
    space(18);
    text("01   나의 하루 목표", 18, ink);
    text("목표는 오늘 누적 시간 기준입니다.", 13, muted);
    LinearLayout goals = new LinearLayout(this);
    page.addView(goals);
    for (int m : new int[] {15, 30, 60}) {
      Button g = new Button(this);
      g.setText(m + "분");
      goals.addView(g, new LinearLayout.LayoutParams(0, -2, 1));
      g.setOnClickListener(
          v -> {
            timer.prefs.edit().putInt("goal", m).apply();
            update();
          });
    }
    space(12);
    text("02   알아차릴 앱 선택", 18, ink);
    text("쇼츠·릴스만이 아닌 앱 전체 시간을 측정합니다.", 13, muted);
    String[][] apps = {
      {"YouTube", "com.google.android.youtube"},
      {"Instagram", "com.instagram.android"},
      {"TikTok", "com.zhiliaoapp.musically"},
      {"TikTok (일부 지역)", "com.ss.android.ugc.trill"}
    };
    for (String[] a : apps) {
      Switch s = new Switch(this);
      s.setText(a[0]);
      s.setTextColor(ink);
      s.setPadding(0, 12, 0, 12);
      s.setChecked(timer.prefs.getBoolean("app_" + a[1], false));
      page.addView(s);
      s.setOnCheckedChangeListener(
          (v, on) -> {
            timer.prefs.edit().putBoolean("app_" + a[1], on).apply();
            if (!on && !timer.manual && timer.source.equals(a[1])) timer.stop();
          });
    }
    space(16);
    text("03   자동 측정 설정", 18, ink);
    Switch auto = new Switch(this);
    auto.setText("자동 측정 사용");
    auto.setChecked(timer.prefs.getBoolean("auto", false));
    page.addView(auto);
    auto.setOnCheckedChangeListener(
        (v, on) -> {
          timer.prefs.edit().putBoolean("auto", on).apply();
          if (!on && !timer.manual) timer.stop();
        });
    overlay =
        button(
            "",
            v ->
                startActivity(
                    new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()))));
    access =
        button(
            "",
            v ->
                new AlertDialog.Builder(this)
                    .setTitle("자동 측정을 위한 접근성 권한")
                    .setMessage(
                        "how many?는 선택한 앱의 실행 여부를 확인해 이용 시간을 측정합니다. 화면 내용, 메시지, 입력한 텍스트는 읽거나 저장하지"
                            + " 않습니다. 앱 선택 및 일별 누적 시간만 기기에 저장하며 서버로 전송하지 않습니다.\n\n"
                            + "동의하면 다음 설정 화면에서 how many?를 켜주세요. 언제든 이 설정에서 해제할 수 있습니다.")
                    .setNegativeButton("취소", null)
                    .setPositiveButton(
                        "동의하고 설정 열기",
                        (d, w) -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                    .show());
    status = label("", 13, muted);
    page.addView(status);
    space(16);
    text("04   직접 시작하기", 18, ink);
    text(
        "권한 없이도 수동 측정이 가능합니다. 다른 앱 위 표시 권한이 없으면 타이머는 이 화면에서 확인하세요. 수동 측정은 화면이 꺼져도 종료할 때까지 계속됩니다.",
        13,
        muted);
    button(
        "수동 타이머 시작",
        v -> {
          if (Build.VERSION.SDK_INT >= 33
              && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                  != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[] {android.Manifest.permission.POST_NOTIFICATIONS}, 1);
          startForegroundService(new Intent(this, ManualService.class));
        });
    button(
        "측정 종료 · 자동 측정 끄기",
        v -> {
          auto.setChecked(false);
          stopService(new Intent(this, ManualService.class));
          timer.stop();
          update();
        });
    space(18);
    text("초록 0–10분  ·  노랑 10–30분  ·  빨강 30분 이상", 12, muted);
    text("색상은 현재 연속 세션 기준입니다. 기회비용은 선택을 돕기 위한 예시이며 개인차가 있습니다.", 12, muted);
    button(
        "기록 삭제",
        v ->
            new AlertDialog.Builder(this)
                .setTitle("이 기기의 측정 기록을 삭제할까요?")
                .setNegativeButton("취소", null)
                .setPositiveButton(
                    "삭제",
                    (d, w) -> {
                      stopService(new Intent(this, ManualService.class));
                      timer.stop();
                      android.content.SharedPreferences.Editor e = timer.prefs.edit();
                      for (String k : timer.prefs.getAll().keySet())
                        if (k.startsWith("day_")) e.remove(k);
                      e.apply();
                      update();
                    })
                .show());
  }

  void update() {
    long ms = timer.today();
    total.setText(TimeRules.clock(ms));
    current.setText(
        timer.running()
            ? (timer.manual ? "수동 측정" : "선택한 앱 측정") + " · " + TimeRules.clock(timer.session)
            : "지금은 쉬어가는 중");
    int goal = timer.prefs.getInt("goal", 30);
    long left = Math.max(0, goal * 60000L - ms);
    insight.setText(
        "\n오늘 목표 "
            + goal
            + "분 · 남은 시간 "
            + TimeRules.clock(left)
            + "\n"
            + (ms >= 600000
                ? "이 시간은 약 " + ms / 60000 + "분의 산책으로도 채울 수 있어요."
                : "다음 5분은 무엇으로 채워볼까요?"));
    overlay.setText(Settings.canDrawOverlays(this) ? "✓ 다른 앱 위 표시 허용됨" : "다른 앱 위 표시 허용하기");
    boolean enabled = false;
    android.view.accessibility.AccessibilityManager am =
        (android.view.accessibility.AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
    for (android.accessibilityservice.AccessibilityServiceInfo s :
        am.getEnabledAccessibilityServiceList(-1))
      if (s.getResolveInfo().serviceInfo.packageName.equals(getPackageName())) enabled = true;
    access.setText(enabled ? "✓ 접근성 서비스 활성화됨" : "접근성 권한 안내 보기");
    status.setText(
        timer.prefs.getBoolean("auto", false) && enabled
            ? "준비됐어요. 선택한 앱을 열면 측정을 시작합니다."
            : "자동 측정에는 자동 측정 스위치와 접근성 권한이 필요합니다.");
  }

  protected void onResume() {
    super.onResume();
    handler.post(refresh);
  }

  protected void onPause() {
    handler.removeCallbacks(refresh);
    super.onPause();
  }

  TextView label(String s, int size, int color) {
    TextView t = new TextView(this);
    t.setText(s);
    t.setTextSize(size);
    t.setTextColor(color);
    t.setPadding(0, 5, 0, 5);
    return t;
  }

  void text(String s, int size, int c) {
    page.addView(label(s, size, c));
  }

  void space(int h) {
    Space s = new Space(this);
    page.addView(s, new LinearLayout.LayoutParams(1, h));
  }

  Button button(String s, View.OnClickListener l) {
    Button b = new Button(this);
    b.setText(s);
    b.setTextColor(ink);
    b.setAllCaps(false);
    b.setOnClickListener(l);
    page.addView(b, new LinearLayout.LayoutParams(-1, -2));
    return b;
  }
}
