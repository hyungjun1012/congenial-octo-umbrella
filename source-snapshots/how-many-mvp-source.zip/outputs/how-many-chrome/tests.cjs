const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const R = require('./rules.js');

test('Shorts, watch and unrelated routes are distinct', () => {
  assert.equal(R.kind('/shorts/abc'), 'shorts');
  assert.equal(R.kind('/watch'), 'video');
  for (const path of ['/','/results','/shorts/','/feed/subscriptions']) assert.equal(R.kind(path), null);
});
const previous={at:1000,position:10,eligible:true,kind:'shorts',video:1,rate:1};
test('Only advancing, focused playback counts real time (including 2x playback)',()=>{
  assert.equal(R.measured(previous,{...previous,at:2000,position:11}),1000);
  assert.equal(R.measured(previous,{...previous,at:2000,position:12,rate:2}),1000);
  for (const change of [{eligible:false},{position:10},{position:40},{position:9},{at:9000},{video:2},{kind:'video'}]) {
    assert.equal(R.measured(previous,{...previous,at:2000,position:11,...change}),0);
  }
});
test('Color boundaries and duration formatting',()=>{
  assert.deepEqual([0,599999,600000,1799999,1800000].map(R.stage),['green','green','yellow','yellow','red']);
  assert.equal(R.clock(3661000),'01:01:01');
});
test('Intervals are split at local midnight',()=>{
  const midnight=new Date(2026,8,22).getTime();
  const days=R.addInterval({},midnight-700,midnight+300,'shorts');
  assert.equal(days['2026-09-21'].shorts,700);
  assert.equal(days['2026-09-22'].shorts,300);
});
function worker() {
  let listener, active=true,focused=true,data={};
  const context={HowManyRules:R,Date,importScripts:()=>{},chrome:{
    runtime:{onMessage:{addListener:fn=>listener=fn}},
    storage:{local:{get:async()=>structuredClone(data),set:async patch=>{data={...data,...structuredClone(patch)};}}},
    tabs:{get:async()=>({active,windowId:1})},windows:{get:async()=>({focused,state:'normal'})}
  }};
  vm.runInNewContext(fs.readFileSync(__dirname+'/background.js','utf8'),context);
  return {send:(message,sender={})=>new Promise(resolve=>listener(message,sender,resolve)),setFocus:a=>focused=a,setActive:a=>active=a};
}
const sender={tab:{id:1},url:'https://www.youtube.com/watch?v=test'};
test('Concurrent samples are serialized without overwriting totals',async()=>{
  const w=worker();
  await Promise.all(Array.from({length:20},()=>w.send({type:'sample',ms:1000,kind:'video'},sender)));
  assert.equal((await w.send({type:'stats'})).today.video,20000);
});
test('Inactive tabs, unfocused windows and disabled tracking cannot accumulate',async()=>{
  const w=worker(),sample={type:'sample',ms:1000,kind:'shorts'};
  w.setFocus(false);assert.equal((await w.send(sample,sender)).accepted,0);
  w.setFocus(true);w.setActive(false);assert.equal((await w.send(sample,sender)).accepted,0);
  w.setActive(true);await w.send({type:'settings',enabled:false});
  assert.equal((await w.send(sample,sender)).accepted,0);
  await w.send({type:'settings',enabled:true});assert.equal((await w.send(sample,sender)).accepted,1000);
});
test('Reject oversized samples and content-script settings changes',async()=>{
  const w=worker();
  assert.equal((await w.send({type:'sample',ms:60000,kind:'video'},sender)).accepted,0);
  assert.equal((await w.send({type:'settings',enabled:false},sender)).settings.enabled,true);
});
