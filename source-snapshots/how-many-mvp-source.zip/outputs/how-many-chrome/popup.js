const $ = id => document.getElementById(id);
async function update(message={type:'stats'}) {
  try {
    const result=await chrome.runtime.sendMessage(message);
    if (result.error) throw Error();
    const {today,settings}=result,total=today.shorts+today.video;
    $('total').textContent=HowManyRules.clock(total);
    for (const kind of ['shorts','video']) $(kind).textContent=HowManyRules.clock(today[kind]);
    $('remaining').textContent=total>=settings.goal*60000?'오늘 목표 시간에 도달했어요.':'목표 '+settings.goal+'분 · 남은 시간 '+HowManyRules.clock(settings.goal*60000-total);
    $('enabled').checked=settings.enabled;$('goal').value=String(settings.goal);$('error').textContent='';
  } catch { $('error').textContent='기록을 불러오지 못했어요. 확장을 새로고침해 주세요.'; }
}
$('enabled').onchange=()=>update({type:'settings',enabled:$('enabled').checked});
$('goal').onchange=()=>update({type:'settings',goal:Number($('goal').value)});
if (globalThis.chrome?.runtime?.id && globalThis.chrome?.runtime?.sendMessage) {
  update();setInterval(()=>update(),1000);
} else {
  $('enabled').disabled=true;
  $('goal').disabled=true;
  $('remaining').textContent='확장 프로그램 설치가 필요합니다';
  $('error').textContent='이 HTML 파일만 열면 측정할 수 없습니다. Chrome 주소창에 chrome://extensions 를 입력 → 개발자 모드 켜기 → 압축해제된 확장 프로그램 로드 → how-many-chrome 폴더 선택 → YouTube 탭 새로고침 순서로 설치해 주세요.';
}
