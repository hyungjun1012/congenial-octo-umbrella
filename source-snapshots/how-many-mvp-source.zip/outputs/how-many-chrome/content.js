(() => {
  if (document.getElementById('how-many-root')) return;
  const R = HowManyRules;
  const host = document.createElement('div');
  host.id = 'how-many-root';
  host.style.cssText = 'position:fixed;right:22px;bottom:28px;z-index:2147483647;display:none';
  const root = host.attachShadow({mode: 'open'});
  root.innerHTML = `<style>
    :host{all:initial} *{box-sizing:border-box}
    .card{width:266px;padding:17px 19px;border-radius:20px;background:#173e34;color:#eff8f0;font:13px/1.5 -apple-system,BlinkMacSystemFont,sans-serif;box-shadow:0 8px 38px #0005;border:1px solid #ffffff24}
    header{display:flex;align-items:center;justify-content:space-between;cursor:move;touch-action:none;user-select:none}
    strong{font-size:17px;letter-spacing:-.5px}button{font:inherit;color:inherit;background:#ffffff18;border:0;border-radius:8px;padding:3px 9px;cursor:pointer}
    .time{font:600 30px/1.4 ui-monospace,monospace;letter-spacing:-1px;margin-top:10px}
    .status{font-size:12px;opacity:.8}.line{margin-top:10px;border-top:1px solid #ffffff26;padding-top:10px}.split{font-size:12px;opacity:.85}.message{margin-top:6px}
    .yellow{background:#f6dda0;color:#493b15}.red{background:#efb0a8;color:#542721}.yellow .line,.red .line{border-color:#0002}
    .compact .details{display:none}.compact{width:178px}.compact .time{font-size:23px}
    button:focus-visible{outline:2px solid currentColor;outline-offset:3px}
  </style><section class="card"><header><strong>how many?</strong><button aria-label="타이머 접기" title="접기/펼치기">−</button></header><div class="time">00:00:00</div><div class="status">재생을 기다리는 중</div><div class="details"><div class="line split"></div><div class="message"></div></div></section>`;
  document.documentElement.append(host);
  const card = root.querySelector('.card'), time = root.querySelector('.time'), status = root.querySelector('.status');
  const split = root.querySelector('.split'), message = root.querySelector('.message');
  let compact = false, previous = null, busy = false, stopped = false;
  root.querySelector('button').onclick = e => {
    compact = !compact; e.target.textContent = compact ? '+' : '−';
    e.target.setAttribute('aria-label', compact ? '타이머 펼치기' : '타이머 접기');
    card.classList.toggle('compact', compact);
  };
  const header = root.querySelector('header');
  let drag = null;
  header.addEventListener('pointerdown', e => {
    if (e.target.closest('button')) return;
    const rect = host.getBoundingClientRect();
    drag = {x:e.clientX, y:e.clientY, left:rect.left, top:rect.top};header.setPointerCapture(e.pointerId);
  });
  header.addEventListener('pointermove', e => {
    if (!drag) return;
    host.style.right = 'auto'; host.style.bottom = 'auto';
    host.style.left = Math.max(0, Math.min(innerWidth-host.offsetWidth, drag.left+e.clientX-drag.x))+'px';
    host.style.top = Math.max(0, Math.min(innerHeight-host.offsetHeight, drag.top+e.clientY-drag.y))+'px';
  });
  header.addEventListener('pointerup', () => drag=null);
  function videoOnScreen() {
    return [...document.querySelectorAll('video')].filter(v => {
      const r = v.getBoundingClientRect();
      return r.width > 50 && r.height > 50 && r.bottom > 0 && r.top < innerHeight && r.right > 0 && r.left < innerWidth;
    }).sort((a,b) => Number(b.paused === false)-Number(a.paused === false))[0];
  }
  async function tick() {
    if (busy || stopped) return;
    busy = true;
    try {
      const kind = R.kind(location.pathname), video = videoOnScreen();
      const ad = !!document.querySelector('.ad-showing, .ad-interrupting');
      const current = {kind,video,at:performance.now(),position:video?.currentTime || 0,rate:video?.playbackRate || 1,
        eligible:!!(kind && video && !video.paused && !video.ended && !video.seeking && video.readyState >= 3 && !ad && document.visibilityState === 'visible' && document.hasFocus())};
      const ms = R.measured(previous,current);previous=current;
      const result = await chrome.runtime.sendMessage({type:'sample',kind,ms});
      if (result.error) throw Error('storage');
      const total = result.today.shorts + result.today.video;
      host.style.display = kind ? 'block' : 'none';
      card.className = 'card '+R.stage(total)+(compact?' compact':'');
      time.textContent = R.clock(total);
      status.textContent = !result.settings.enabled ? '측정 꺼짐 · 확장 메뉴에서 켜기' : result.accepted > 0 ? '오늘 누적 · '+(kind === 'shorts'?'쇼츠':'일반 영상')+' 측정 중' : ad ? '광고 · 측정 일시정지' : '오늘 누적 · 재생 / 활성 탭 대기';
      split.textContent = '쇼츠 '+R.clock(result.today.shorts)+' · 일반 '+R.clock(result.today.video);
      message.textContent = total >= result.settings.goal*60000 ? '오늘 목표 시간에 도달했어요. 잠깐 쉬어갈까요?' : total >= 600000 ? '다음 5분은 나를 위해 써보세요.' : '지금, 내 시간을 알아차리는 중';
    } catch (e) {
      previous=null;status.textContent='확장 연결 끊김 · 페이지 새로고침';
      stopped=true;clearInterval(interval);
    } finally {busy=false;}
  }
  for (const event of ['blur','focus','pagehide']) window.addEventListener(event,()=>previous=null);
  document.addEventListener('visibilitychange',()=>previous=null);
  document.addEventListener('yt-navigate-start',()=>previous=null);
  document.addEventListener('fullscreenchange',()=>{
    const target = document.fullscreenElement || document.documentElement;
    if (target.tagName !== 'VIDEO') target.append(host);
    previous=null;
  });
  const interval=setInterval(tick,1000);tick();
})();
