importScripts('rules.js');
const defaults = {enabled: true, goal: 30};
let queue = Promise.resolve();

async function handle(message, sender) {
  const saved = await chrome.storage.local.get(['days', 'settings']);
  const days = saved.days || {};
  const settings = {...defaults, ...saved.settings};
  let accepted = 0;
  if (message.type === 'sample' && settings.enabled && sender.tab && ['shorts', 'video'].includes(message.kind)) {
    const ms = Number(message.ms);
    if (Number.isFinite(ms) && ms > 0 && ms <= 2500 && sender.url?.startsWith('https://www.youtube.com/')) {
      const tab = await chrome.tabs.get(sender.tab.id);
      const win = await chrome.windows.get(tab.windowId);
      if (tab.active && win.focused && win.state !== 'minimized') {
        const end = Date.now();
        HowManyRules.addInterval(days, end - ms, end, message.kind);
        // Keep only the last 90 recorded days; never store titles or URLs.
        for (const key of Object.keys(days).sort().slice(0, -90)) delete days[key];
        await chrome.storage.local.set({days});
        accepted = ms;
      }
    }
  } else if (message.type === 'settings' && !sender.tab) {
    if (typeof message.enabled === 'boolean') settings.enabled = message.enabled;
    if ([15, 30, 60].includes(message.goal)) settings.goal = message.goal;
    await chrome.storage.local.set({settings});
  }
  return {today: days[HowManyRules.dayKey(new Date())] || {shorts: 0, video: 0}, settings, accepted};
}

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (!message || !['sample', 'stats', 'settings'].includes(message.type)) return;
  // Serialize read-modify-write so simultaneous tabs cannot lose increments.
  queue = queue.then(() => handle(message, sender)).then(reply).catch(() => reply({error: true}));
  return true;
});
