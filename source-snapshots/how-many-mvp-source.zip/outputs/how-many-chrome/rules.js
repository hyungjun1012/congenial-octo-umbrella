/* Shared, pure measurement rules. */
(function (root) {
  const kind = path => /^\/shorts\/[^/]+/.test(path) ? 'shorts' : path === '/watch' ? 'video' : null;
  const dayKey = date => [date.getFullYear(), String(date.getMonth() + 1).padStart(2, '0'), String(date.getDate()).padStart(2, '0')].join('-');
  const clock = ms => {
    const s = Math.floor(Math.max(0, ms) / 1000);
    return [Math.floor(s / 3600), Math.floor(s / 60) % 60, s % 60].map(n => String(n).padStart(2, '0')).join(':');
  };
  const stage = ms => ms < 600000 ? 'green' : ms < 1800000 ? 'yellow' : 'red';
  function measured(previous, current) {
    if (!previous || !previous.eligible || !current.eligible || previous.kind !== current.kind || previous.video !== current.video) return 0;
    const elapsed = current.at - previous.at;
    const progress = current.position - previous.position;
    // Ignore sleep/throttling gaps, buffering, backwards seeks and jumps.
    if (elapsed <= 0 || elapsed > 2500 || progress <= 0 || progress > elapsed / 1000 * current.rate + 1) return 0;
    return elapsed;
  }
  function addInterval(days, start, end, type) {
    let cursor = start;
    while (cursor < end) {
      const date = new Date(cursor), key = dayKey(date);
      const midnight = new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1).getTime();
      const next = Math.min(end, midnight);
      const row = days[key] || {shorts: 0, video: 0};
      row[type] += next - cursor;
      days[key] = row;
      cursor = next;
    }
    return days;
  }
  root.HowManyRules = {kind, dayKey, clock, stage, measured, addInterval};
  if (typeof module !== 'undefined') module.exports = root.HowManyRules;
})(globalThis);
