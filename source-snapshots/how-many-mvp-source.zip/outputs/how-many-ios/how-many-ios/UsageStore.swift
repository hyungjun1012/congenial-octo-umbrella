import Foundation
import SwiftUI

@MainActor
final class UsageStore: ObservableObject {
    @Published private(set) var sessionSeconds: Int = 0
    @Published private(set) var todaySeconds: Int
    @Published private(set) var isRunning = false

    private var timer: Timer?
    private let defaults = UserDefaults.standard
    private let todayKey = "howMany.todaySeconds"
    private let dateKey = "howMany.date"

    init() {
        let today = ISO8601DateFormatter().string(from: Date()).prefix(10)
        if defaults.string(forKey: dateKey) == today {
            todaySeconds = defaults.integer(forKey: todayKey)
        } else {
            defaults.set(String(today), forKey: dateKey)
            defaults.set(0, forKey: todayKey)
            todaySeconds = 0
        }
    }

    func toggle() {
        isRunning ? stop() : start()
    }

    func start() {
        guard !isRunning else { return }
        isRunning = true
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            guard let self else { return }
            self.sessionSeconds += 1
            self.todaySeconds += 1
            self.defaults.set(self.todaySeconds, forKey: self.todayKey)
        }
    }

    func stop() {
        timer?.invalidate()
        timer = nil
        isRunning = false
    }

    func resetToday() {
        stop()
        sessionSeconds = 0
        todaySeconds = 0
        defaults.set(0, forKey: todayKey)
    }

    deinit { timer?.invalidate() }
}
