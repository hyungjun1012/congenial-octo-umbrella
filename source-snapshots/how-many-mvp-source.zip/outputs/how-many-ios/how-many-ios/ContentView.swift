import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: UsageStore
    @AppStorage("howMany.goalMinutes") private var goalMinutes = 30
    @State private var showingScreenTimeInfo = false

    private var stage: Stage {
        Stage(seconds: store.sessionSeconds)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("HOW MANY?  /  DIGITAL WELLBEING")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    Text("스크롤 사이,\n나를 위한 시간.")
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                    Text("iOS에서 측정 가능한 범위부터 시작합니다.")
                        .foregroundStyle(.secondary)

                    VStack(alignment: .leading, spacing: 8) {
                        Text("현재 세션")
                            .foregroundStyle(.white.opacity(0.75))
                        Text(format(store.sessionSeconds))
                            .font(.system(size: 42, weight: .bold, design: .monospaced))
                            .foregroundStyle(.white)
                        Text(stage.message)
                            .foregroundStyle(.white.opacity(0.85))
                    }
                    .padding(24)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(stage.color, in: RoundedRectangle(cornerRadius: 28))

                    VStack(alignment: .leading, spacing: 8) {
                        Text("오늘 누적")
                            .font(.headline)
                        Text(format(store.todaySeconds))
                            .font(.system(size: 28, weight: .bold, design: .monospaced))
                        Text("목표 (goalMinutes)분 · 남은 시간 (format(max(0, goalMinutes * 60 - store.todaySeconds)) )")
                            .foregroundStyle(.secondary)
                    }

                    HStack(spacing: 12) {
                        Button(store.isRunning ? "측정 종료" : "수동 측정 시작") {
                            store.toggle()
                        }
                        .buttonStyle(.borderedProminent)
                        Button("기록 삭제") { store.resetToday() }
                            .buttonStyle(.bordered)
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        Text("목표 시간")
                            .font(.headline)
                        Picker("목표 시간", selection: $goalMinutes) {
                            Text("15분").tag(15)
                            Text("30분").tag(30)
                            Text("60분").tag(60)
                        }
                        .pickerStyle(.segmented)
                    }

                    Button {
                        showingScreenTimeInfo = true
                    } label: {
                        Label("Screen Time 연동 안내", systemImage: "hourglass")
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .buttonStyle(.bordered)
                }
                .padding(22)
            }
            .navigationTitle("how many?")
            .sheet(isPresented: $showingScreenTimeInfo) {
                ScreenTimeInfoView()
            }
        }
    }

    private func format(_ seconds: Int) -> String {
        String(format: "%02d:%02d:%02d", seconds / 3600, (seconds / 60) % 60, seconds % 60)
    }
}

private enum Stage {
    case safe, caution, warning

    init(seconds: Int) {
        self = seconds < 600 ? .safe : seconds < 1800 ? .caution : .warning
    }

    var color: Color {
        switch self {
        case .safe: .green
        case .caution: .orange
        case .warning: .red
        }
    }

    var message: String {
        switch self {
        case .safe: "지금, 내 시간을 알아차리는 중"
        case .caution: "잠깐 쉬어갈까요?"
        case .warning: "다음 5분은 나를 위해 써보세요"
        }
    }
}

private struct ScreenTimeInfoView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("가능한 기능") {
                    Label("앱별 일일 사용 시간 리포트", systemImage: "chart.bar")
                    Label("설정한 시간 초과 알림", systemImage: "bell")
                    Label("앱 차단 화면", systemImage: "hand.raised")
                }
                Section("iOS의 제한") {
                    Text("다른 앱 위에 타이머를 띄울 수 없습니다.")
                    Text("YouTube Shorts와 일반 YouTube 영상은 구분하지 못합니다.")
                    Text("Family Controls 권한과 Apple entitlement 승인이 필요합니다.")
                }
            }
            .navigationTitle("Screen Time 연동")
            .toolbar { Button("닫기") { dismiss() } }
        }
    }
}

#Preview { ContentView().environmentObject(UsageStore()) }
