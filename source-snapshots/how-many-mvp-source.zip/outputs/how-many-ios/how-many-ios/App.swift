import SwiftUI

@main
struct HowManyApp: App {
    @StateObject private var store = UsageStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
        }
    }
}
