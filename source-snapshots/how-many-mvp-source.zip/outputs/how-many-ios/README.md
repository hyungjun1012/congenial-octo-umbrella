# how many? — iOS MVP

Xcode에서 열어 실행하는 iOS용 프로토타입입니다.

현재 포함된 기능:

- 수동 세션 타이머
- 0–10분 초록, 10–30분 노랑, 30분 이상 빨강 상태
- 오늘 누적 시간과 목표 시간
- Screen Time 권한/제약을 설명하는 안내 화면
- 기록은 기기 안에만 저장

## 실행

1. Xcode를 설치합니다.
2. `how-many-ios.xcodeproj`를 엽니다.
3. iPhone 또는 iPad Simulator를 선택합니다.
4. `how many?` 스킴을 실행합니다.

이 프로젝트의 수동 타이머는 시뮬레이터에서도 바로 확인할 수 있습니다. 다른 앱의 사용시간 자동 측정은 Apple의 Family Controls/DeviceActivity entitlement가 필요합니다. 앱별 리포트와 차단 기능을 연결하려면 Apple Developer 계정에서 해당 capability를 요청하고 Xcode에서 활성화해야 합니다.

## iOS 제약

iOS는 다른 앱 위에 플로팅 오버레이를 허용하지 않습니다. 앱별 체류 시간과 임계값 알림은 DeviceActivity로 구현하고, 잠금화면/Dynamic Island 표시는 ActivityKit Live Activity로 별도 추가합니다. YouTube Shorts와 일반 YouTube 영상처럼 한 앱 내부 콘텐츠 유형은 시스템 사용량 API만으로 구분하지 않습니다.
